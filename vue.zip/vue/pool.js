//加载模块
const mysql=require('mysql');
//创建连接池
var pool=mysql.createPool({
    host:'w.rdc.sae.sina.com.cn',
    user:'jm1jxn43yk',
    password:'illmij4i4z2myx1k35xmk20wj432yywwjlxlwwi3',
    port:3306,
    database:'app_mllvue',
    connectionLimit:20
})
//导出连接池
module.exports=pool;
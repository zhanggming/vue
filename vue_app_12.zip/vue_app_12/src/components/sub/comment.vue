<template>
    <div class="app-comment">
       <div class="mui-card">
			 <div class="mui-card-content">
				 <div class="mui-card-content-inner">
					<h4>发表评论</h4>
			     </div>
                 </div>
                 <textarea type="text" placeholder="请输入内容" maxlength="120" v-model="msg">
                </textarea>
                <mt-button type="primary" size="large" @click="addcomment">发表评论</mt-button>
			 </div>
                
			 <div class="mui-card-footer">
              <div class="cmt-list">
                  <div class="cmt-item" v-for="(item,i) in list" :key="item.id">
                   <div>{{i+1}}楼 发表时间：{{item.ctime | dateFilter}}</div>
                   <div>{{item.content}}</div>
                </div>
             </div>
	   </div>
    </div>
</template>
<script>
import {Toast} from 'mint-ui'
    export default{
        data(){
            return{
              list:[],
              pno:0,
              pageSize:5,
              msg:""
            }
        },
        methods:{
            addcomment(){
                //添加点击事件
                //console.log(123)
                //获取评论内容
                var m=this.msg;
                //判断内容
                m.trim();
                var size=m.trim().length;
                if(size==0){
                    Toast("评论内容不能为空")
                    return;
                }
                //获取当前新闻的id
                var nid=this.$route.query.nid;
                //console.log(nid);
                //配置对象
                var postDate=this.qs.stringify({
                    nid:nid,
                    content:this.msg
                });
                var url="http://127.0.0.1:3002/index/";
                url+="addComment";
                this.axios.post(url,postDate).then(result=>{
                    //console.log(result.data.msg);
                    this.msg="";
                    this.pno=0;
                    this.list=[];
                    this.getMore();
                });
            },
            getMore(){
             this.pno++;
             var url="http://127.0.0.1:3002/index";
             url+="/getComment?nid="+this.$route.query.nid;
             url+="&pno="+this.pno;
             url+="&pageSize="+this.pageSize;
             this.axios.get(url).then(result=>{
                 var rows=this.list.concat(result.data.data);
                 this.list=rows;
             })
            }
        },
        created() {
            this.getMore();
        },
    }
</script>
<style >
    
</style>
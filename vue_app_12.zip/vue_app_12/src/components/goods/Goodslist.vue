<template>
    <div class="app-goodslist">
     <div class="goods-item" v-for="(item,i) of list" :key="i.fid">
         <img :src="'http://127.0.0.1:3002/'+item.img" @click="jumpInfo" :data-id="item.fid">
         <h4>{{item.title}}</h4>
         <div class="info">
             <span class="now">{{item.price1}}</span>
         </div>
         <div class="sell">
           <span>销售量{{item.price1}}</span>
           <span>{{item.subtitle}}</span>
         </div>
     </div>
     <mt-button type="primary" size="large" @click="getMore">加载更多</mt-button>
    </div>
</template>
<script>
    export default{
        data(){
            return{
                list:[],
                pno:0,
                pageSize:4
            }
        },
        methods:{
            jumpInfo(e){
                var id=e.target.dataset.id;
                
                this.$router.push("/Goodsinfo?id="+id)
            //console.log(id)
            },
            getMore(){
                this.pno++;
                var url="http://127.0.0.1:3002/index";
                url+="/products?pno="+this.pno;
                url+="&pageSize="+this.pageSize;
                this.axios.get(url).then(result=>{
                   // console.log(result.data.data)
                 var rows=this.list.concat(result.data.data);
                 this.list=rows;
                })
            },
            getGoodslist(){
                var url="http://127.0.0.1:3002/index/products";
                this.axios.get(url).then(result=>{
                    this.list=result.data.data
                })
            }
        },
        created() {
            this.getGoodslist();
        },
    }
</script>
<style>
    .app-goodslist{
        display:flex;
        flex-wrap:wrap;
        justify-content:space-between;
        padding:4px;
    }
    .app-goodslist .goods-item{
        width:49%;
        border:1px solid #ccc;
        box-shadow:0 0 8px #ccc;
        margin:4px 0;
        padding:2px;
        display:flex;
        flex-direction:column;
        min-height:230px;
        justify-content:space-between;
        text-align:center;
    }
    .app-goodslist .goods-item img{width:100%}
    .app-goodslist .goods-item h4{font-size:12px;}
    .app-goodslist .goods-item .now{
        color:red;
        font-size:16px;
        font-weight:bold;
    }
</style>
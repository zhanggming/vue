<template>
   <div>
       <input type="text">
       <mt-button type="primary">搜索</mt-button>
   </div>
</template>
<script>
    export default{
        data(){
            return{}
        }
    }
</script>
<style lang="">
    
</style>
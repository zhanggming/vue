<template>
   <div class="app-goodinfo">
      <div class="mui-card">
				<div class="mui-card-content">
					<div class="mui-card-content-inner">
					   <swiper-box :list="rows"></swiper-box>
					</div>
			   </div>	
        </div>
            <!--调用-->
        <div class="mui-card">
				<div class="mui-card-header">商品信息</div>
				<div class="mui-card-content">
					<div class="mui-card-content-inner">
						<p>销售价：{{info.price1}}</p>
                        购买数量：<div class="mui-numbox">
					<button class="mui-btn mui-btn-numbox-minus" type="button" @click="goodSub">-</button>
					<input class="mui-input-numbox" type="number" value="1" v-model="val"/>
					<button class="mui-btn mui-btn-numbox-plus" type="button" @click="goodAdd">+</button>
				</div>
					</div>
				</div>
				<div class="mui-card-footer">
                  <mt-button type="danger" size=small @click="addcart">加入购物车</mt-button>
                </div>
			</div>    
  </div>
</template>
<script>
    import  {Toast} from 'mint-ui'
    import swiperBox from '../sub/swiperBox.vue'
    export default{
        data(){
            return{
                rows:[],
                info:{},
                id:this.$route.query.id,
                
                val:1
            }
        },
        methods:{
            goodAdd(){
                this.val++;
            },
            goodSub(){
                if(this.val>1){
                    this.val--;
                }
            },
            findGoodsinfo(){
                var url="http://127.0.0.1:3002/index/products?id="+this.id;
                this.axios.get(url).then(result=>{
                    this.info=result.data.data[0];
                })
            },
             getImages(){
             var url = "http://127.0.0.1:3002/index/imglist";
             this.axios.get(url).then(result=>{
               this.rows = result.data;
               //console.log(result)
             });
            },
            addcart(){
                //绑定事件
               // console.log(123)
               //获取两个参数
               var pid=this.id;
               var price=this.info.price1;
               var uid=1;
               //console.log(pid+'-'+price+'-'+uid)
               //ajax请求
               var url="http://127.0.0.1:3002/index/"
               url+="addcart?pid="+pid;
               url+="&price="+price;
               url+="&uid="+uid;
               this.axios.get(url).then(result=>{
                   if(result.data.code==1){
                       Toast("添加成功");
                   }else{
                       Toast("添加失败")
                   }
               })
            }
        },
        created() {
            this.getImages();
            this.findGoodsinfo();
        },
        components:{
            "swiper-box":swiperBox
        }
    }
</script>
<style>
    
</style>
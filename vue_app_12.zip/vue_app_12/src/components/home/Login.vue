<template>
   <div class="app-login">
       <div class="mui-card">
				<div class="mui-card-header">
                 <h3>用户登录</h3>
                </div>
				<div class="mui-card-content">
					<div class="mui-card-content-inner">
					<form>
          用户名<input type="text" name="uname" v-model="uname"/>
          密码<input type="password" name="upwd" v-model="upwd"/>
          <!--<input type="button" value="登录" @click="butLogin">-->
          </form>
					</div>
				</div>
			<div class="mui-card-footer"><mt-button type="primary" size="large" @click="butLogin">登录</mt-button></div>
			</div>
   </div>
</template>
<script>
 import {Toast} from 'mint-ui'
    export default{
        data(){
            return{uname:"",upwd:""}
        },
        methods:{
            butLogin(){
                //获取用户输入的用户名和密码
                //console.log(123)
                var u=this.uname;
                var p=this.upwd;
                //console.log(u+"-"+p);
                //验证不能为空
                var reg=/^[a-z0-9]{3,12}$/i;
                if(!reg.test(u)){
                    Toast("用户名格式不正确,请检查");
                    return;
                }
                //发送ajax请求
                var url="http://127.0.0.1:3002/index/";
                url+="login?uname="+u+"&upwd="+p;
                this.axios.get(url).then(result=>{
                    //console.log(result.data.data)
                 var res=result.data.code;
                 if(res==-1){
                     Toast("登录失败,请检查用户名和密码是否有误");
                     return;
                 }else{
                     Toast("登录成功")
                     this.$router.push("/Home")
                 }   
                })
            }
        }
    }
</script>
<style>
    
</style>
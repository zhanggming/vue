import Vue from 'vue'
import Router from 'vue-router'
import HelloContainer from "./components/HelloWorld.vue"
import Home from "./components/tabber/Home"
import Newslist from "./components/home/Newslist.vue"
import NewsInfo from "./components/home/NewsInfo.vue"
import Goodslist from "./components/goods/Goodslist.vue"
import GoodsInfo from "./components/goods/GoodsInfo.vue"
import Login from "./components/home/Login.vue"
import ShopCart from "./components/home/ShopCart.vue"
import Search from "./components/goods/Search.vue"
Vue.use(Router)

export default new Router({
  routes: [
    //{path:'/',component:HelloContainer},
    {path:'/',redirect:'/Home'},
    {path:'/Home',component:Home},
    {path:'/Newslist',component:Newslist},
    {path:'/NewsInfo',component:NewsInfo},
    {path:'/Goodslist',component:Goodslist},
    {path:'/GoodsInfo',component:GoodsInfo},
    {path:"/Login",component:Login},
    {path:"/ShopCart",component:ShopCart},
    {path:"/Search",component:Search}
  ]
})

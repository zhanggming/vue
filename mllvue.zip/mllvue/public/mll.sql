SET NAMES UTF8;
DROP DATABASE IF EXISTS mll;
CREATE DATABASE mll CHARSET=UTF8;
USE mll;
/*网页头*/
CREATE TABLE mll_head_title(
  hid INT PRIMARY KEY AUTO_INCREMENT,
  title VARCHAR(64)
);
INSERT INTO mll_head_title VALUES
 (NULL,"北京站"),
 (NULL,"[切换]"),
 (NULL,"请注册"),
 (NULL,"请登录"), 
 (NULL,"我的美乐乐"), 
 (NULL,"购物车"), 
 (NULL,"关注美乐乐"), 
 (NULL,"帮助中心"),  
 (NULL,"收藏本站"),  
 (NULL,"全国热线：4000098666"),
 (NULL,"搜索"),
 (NULL,"抢20抵200翻倍红包"),    
 (NULL,"床"), 
 (NULL,"沙发"),
 (NULL,"餐桌椅"),
 (NULL,"实木床"),
 (NULL,"床垫大促"),
 (NULL,"转角沙发"),
 (NULL,"灯饰"),
 (NULL,"商品分类"),
 (NULL,"首页"),
 (NULL,"家具城"),
 (NULL,"建材城"),
 (NULL,"家居家饰"),
 (NULL,"团购"),
 (NULL,"体验馆阅木"),
 (NULL,"晒家"),
 (NULL,"图览家居");
 /**/
 CREATE TABLE mll_head_img(
 gid INT PRIMARY KEY AUTO_INCREMENT,
  img VARCHAR(128)
);
INSERT INTO mll_head_img VALUES
(NULL,'./img/index/head/logo2.png'),
(NULL,'./img/index/head/head.gif');
/**顶部商品分类**/
CREATE TABLE mll_index_product(
  pid INT PRIMARY KEY AUTO_INCREMENT,
  title VARCHAR(64)
);
INSERT INTO mll_index_product VALUES
 (NULL,"猜你喜欢"),
 (NULL,"分类选择"),
 (NULL,"中式家具"),
 (NULL,"现代家具"), 
 (NULL,"中式家具"), 
 (NULL,"美式家具"), 
 (NULL,"北欧家具"), 
 (NULL,"韩式家具"),  
 (NULL, "地中海家具"),  
 (NULL,"简欧家具"),  
 (NULL,"古典家具"),
 (NULL,"简美家具"),    
 (NULL,"法式家具"), 
 (NULL,"卧室家具"),
 (NULL,"客厅家具"),
 (NULL,"餐厅家具"),
 (NULL,"书房家具"),
 (NULL,"户外家具"),
 (NULL,"实木双人床"),
 (NULL,"特价衣柜"),
 (NULL,"特价家具"),
 (NULL,"实木衣柜"),
 (NULL,"双人床"),
 (NULL,"实木家具"),
 (NULL,"松木家具"),
 (NULL,"红木家具"),
 (NULL,"真皮家具"),
 (NULL,"布艺家具"),
 (NULL,"榆木家具"),
 (NULL,"乳胶床垫"),
 (NULL,"板式家具"),
 (NULL,"大理石"),
 (NULL,"不锈钢"),
 (NULL,"藤艺家具");
/**顶部banner图**/
CREATE TABLE mll_index_carousel(
  cid INT PRIMARY KEY AUTO_INCREMENT,
  img VARCHAR(128),
  title VARCHAR(64),
  href VARCHAR(128)
);
INSERT INTO mll_index_carousel VALUES
 (NULL, './img/index/banner/banner1.jpg','轮播广告商品1','product_details.html?lid=28'),
 (NULL, './img/index/banner/banner2.jpg','轮播广告商品2','product_details.html?lid=19'),
 (NULL, './img/index/banner/banner3.jpg','轮播广告商品3','lookforward.html'),
 (NULL, './img/index/banner/banner4.jpg','轮播广告商品4','lookforward.html'),
 (NULL, './img/index/banner/arrow-left.png','轮播广告商品3','lookforward.html'),
 (NULL, './img/index/banner/arrow-right.png','轮播广告商品4','lookforward.html');
/*2楼商品*/
 CREATE TABLE mll_index_firstFloor(
  fid INT PRIMARY KEY AUTO_INCREMENT,
  img VARCHAR(128),
  title VARCHAR(64),
  price1 DECIMAL(10,2),
  discount VARCHAR(32),
  price2 DECIMAL(10,2),      
  subtitle VARCHAR(128)
);
INSERT INTO mll_index_firstFloor VALUES
(NULL,'./img/index/f2/floor1.jpg','皮布结合 功能性头枕 高档绒布 靠包可拆洗时 尚转角沙发(1+3+左贵妃)',1699.00,'6.8折',2499.00,'去看看'),
(NULL,'./img/index/f2/floor2.jpg','皮布结合 功能性头枕 高档绒布 靠包可拆洗时 尚转角沙发(1+3+左贵妃)',1699.00,'6.8折',2499.00,'去看看'),
(NULL,'./img/index/f2/floor3.jpg','皮布结合 功能性头枕 高档绒布 靠包可拆洗时 尚转角沙发(1+3+左贵妃)',1699.00,'6.8折',2499.00,'去看看'),
(NULL,'./img/index/f2/floor4.jpg','皮布结合 功能性头枕 高档绒布 靠包可拆洗时 尚转角沙发(1+3+左贵妃)',1699.00,'6.8折',2499.00,'去看看'),
(NULL,'./img/index/f2/floor5.jpg','皮布结合 功能性头枕 高档绒布 靠包可拆洗时 尚转角沙发(1+3+左贵妃)',1699.00,'6.8折',2499.00,'去看看'),
(NULL,'./img/index/f2/floor6.jpg','皮布结合 功能性头枕 高档绒布 靠包可拆洗时 尚转角沙发(1+3+左贵妃)',1699.00,'6.8折',2499.00,'去看看'),
(NULL,'./img/index/f2/floor7.jpg','皮布结合 功能性头枕 高档绒布 靠包可拆洗时 尚转角沙发(1+3+左贵妃)',1699.00,'6.8折',2499.00,'去看看'),
(NULL,'./img/index/f2/floor8.jpg','皮布结合 功能性头枕 高档绒布 靠包可拆洗时 尚转角沙发(1+3+左贵妃)',1699.00,'6.8折',2499.00,'去看看'),
(NULL,'./img/index/f2/floor1.jpg','皮布结合 功能性头枕 高档绒布 靠包可拆洗时 尚转角沙发(1+3+左贵妃)',1699.00,'6.8折',2499.00,'去看看'),
(NULL,'./img/index/f2/floor2.jpg','皮布结合 功能性头枕 高档绒布 靠包可拆洗时 尚转角沙发(1+3+左贵妃)',1699.00,'6.8折',2499.00,'去看看'),
(NULL,'./img/index/f2/floor3.jpg','皮布结合 功能性头枕 高档绒布 靠包可拆洗时 尚转角沙发(1+3+左贵妃)',1699.00,'6.8折',2499.00,'去看看'),
(NULL,'./img/index/f2/floor4.jpg','皮布结合 功能性头枕 高档绒布 靠包可拆洗时 尚转角沙发(1+3+左贵妃)',1699.00,'6.8折',2499.00,'去看看'),
(NULL,'./img/index/f2/floor5.jpg','皮布结合 功能性头枕 高档绒布 靠包可拆洗时 尚转角沙发(1+3+左贵妃)',1699.00,'6.8折',2499.00,'去看看'),
(NULL,'./img/index/f2/floor6.jpg','皮布结合 功能性头枕 高档绒布 靠包可拆洗时 尚转角沙发(1+3+左贵妃)',1699.00,'6.8折',2499.00,'去看看'),
(NULL,'./img/index/f2/floor7.jpg','皮布结合 功能性头枕 高档绒布 靠包可拆洗时 尚转角沙发(1+3+左贵妃)',1699.00,'6.8折',2499.00,'去看看'),
(NULL,'./img/index/f2/floor8.jpg','皮布结合 功能性头枕 高档绒布 靠包可拆洗时 尚转角沙发(1+3+左贵妃)',1699.00,'6.8折',2499.00,'去看看');
/*3楼广告*/
CREATE TABLE mll_index_secondFloor(
  tid INT PRIMARY KEY AUTO_INCREMENT,
  img VARCHAR(128),
  title VARCHAR(64),
  count INT
);
INSERT INTO mll_index_secondFloor VALUES
 (NULL,'./img/index/f3/floor1.jpg','NULL',NULL),
 (NULL,'NULL','预约到店送礼',NULL),
 (NULL,'NULL','今天已有',NULL),
 (NULL,'NULL','NULL',639),
 (NULL,'NULL','位客户预约',NULL),
 (NULL,'NULL','所在城市:',NULL),
 (NULL,'NULL','北京',NULL),
 (NULL,'NULL','上海',NULL),
 (NULL,'NULL','北京',NULL),
 (NULL,'NULL','选择门店:',NULL),
 (NULL,'NULL','北京三环体验馆',NULL),
 (NULL,'NULL','上海',NULL),
 (NULL,'NULL','广州',NULL),
 (NULL,'NULL','接收地址:',NULL),
 (NULL,'NULL','请输入手机号码',NULL),
 (NULL,'NULL','立即预约',NULL),
 (NULL,'NULL','恭喜以下成功预约的客户',NULL);
 /*4楼图片*/
 CREATE TABLE mll_index_threeFloor(
  kid INT PRIMARY KEY AUTO_INCREMENT,
  img VARCHAR(128)
);
INSERT INTO mll_index_threeFloor VALUES
 (NULL,'./img/index/f4/floor1.png'),
 (NULL,'./img/index/f4/floor2.jpg'),
 (NULL,'./img/index/f4/floor3.jpg');
 /*4楼title*/
  CREATE TABLE mll_index_threeTitle(
  mid INT PRIMARY KEY AUTO_INCREMENT,
  title VARCHAR(64)
);
INSERT INTO mll_index_threeTitle VALUES
 (NULL,'现代沙发'),
 (NULL,'美式沙发'),
 (NULL,'小户型沙发'),
 (NULL,'电视柜'),
 (NULL,'欧式沙发'),
 (NULL,'布式匹沙发'),
 (NULL,'酒柜'),
 (NULL,'鞋柜'),
 (NULL,'茶几');
 /*4楼商品*/
 CREATE TABLE mll_index_threeProduct(
  nid INT PRIMARY KEY AUTO_INCREMENT,
  img VARCHAR(128),
  title VARCHAR(64),
  price1 DECIMAL(10,2),
  price2 DECIMAL(10,2),      
  h1 VARCHAR(128),
  h2   VARCHAR(128),
  countent INT
);
INSERT INTO mll_index_threeProduct VALUES
 (NULL,'./img/index/f4/floor4.jpg','名流之选 巴西进口头层黄牛皮 五档调节头枕左转角沙发（1+3+左贵妃）',1699.00,2499.00,'直降','已售',2576),
 (NULL,'./img/index/f4/floor5.jpg','名流之选 巴西进口头层黄牛皮 五档调节头枕左转角沙发（1+3+左贵妃）',1699.00,2499.00,'直降','已售',2576),
 (NULL,'./img/index/f4/floor6.jpg','名流之选 巴西进口头层黄牛皮 五档调节头枕左转角沙发（1+3+左贵妃）',1699.00,2499.00,'直降','已售',2576),
 (NULL,'./img/index/f4/floor7.jpg','名流之选 巴西进口头层黄牛皮 五档调节头枕左转角沙发（1+3+左贵妃）',1699.00,2499.00,'直降','已售',2576),
 (NULL,'./img/index/f4/floor8.jpg','名流之选 巴西进口头层黄牛皮 五档调节头枕左转角沙发（1+3+左贵妃）',1699.00,2499.00,'直降','已售',2576),
 (NULL,'./img/index/f4/floor9.jpg','名流之选 巴西进口头层黄牛皮 五档调节头枕左转角沙发（1+3+左贵妃）',1699.00,2499.00,'直降','已售',2576),
 (NULL,'./img/index/f4/floor10.jpg','名流之选 巴西进口头层黄牛皮 五档调节头枕左转角沙发（1+3+左贵妃）',1699.00,2499.00,'直降','已售',2576),
 (NULL,'./img/index/f4/floor11.jpg','名流之选 巴西进口头层黄牛皮 五档调节头枕左转角沙发（1+3+左贵妃）',1699.00,2499.00,'直降','已售',2576);
 /*5楼*/
 CREATE TABLE mll_index_lastFloor(
  qid INT PRIMARY KEY AUTO_INCREMENT,
  img VARCHAR(128),
  title VARCHAR(64),
  price1 DECIMAL(10,2),
  price2 DECIMAL(10,2),      
  h1 VARCHAR(128),
  h2   VARCHAR(128),
  countent INT
);
INSERT INTO mll_index_lastFloor VALUES
 (NULL,'./img/index/f7/floor1.jpg','NULL',NULL,NULL,'NULL','NULL',NULL),
 (NULL,'./img/index/f7/floor2.jpg','名流之选 巴西进口头层黄牛皮 五档调节头枕左转角沙发（1+3+左贵妃）',1699.00,2499.00,'直降','已售',2576),
 (NULL,'./img/index/f7/floor3.jpg','名流之选 巴西进口头层黄牛皮 五档调节头枕左转角沙发（1+3+左贵妃）',1699.00,2499.00,'直降','已售',2576),
 (NULL,'./img/index/f7/floor4.jpg','名流之选 巴西进口头层黄牛皮 五档调节头枕左转角沙发（1+3+左贵妃）',1699.00,2499.00,'直降','已售',2576);
 /*6楼*/
CREATE TABLE mll_index_lastProduct(
  vid INT PRIMARY KEY AUTO_INCREMENT,
  img VARCHAR(128),
  title VARCHAR(64),
  price1 DECIMAL(10,2),
  price2 DECIMAL(10,2),      
  h1 VARCHAR(128),
  h2   VARCHAR(128),
  countent INT
);
INSERT INTO mll_index_lastProduct VALUES
 (NULL,'./img/index/f8/floor1.jpg','NULL',NULL,NULL,'NULL','NULL',NULL),
 (NULL,'./img/index/f8/floor2.jpg','名流之选 巴西进口头层黄牛皮 五档调节头枕左转角沙发（1+3+左贵妃）',1699.00,2499.00,'直降','已售',2576),
 (NULL,'./img/index/f8/floor3.jpg','名流之选 巴西进口头层黄牛皮 五档调节头枕左转角沙发（1+3+左贵妃）',1699.00,2499.00,'直降','已售',2576),
 (NULL,'./img/index/f8/floor4.jpg','名流之选 巴西进口头层黄牛皮 五档调节头枕左转角沙发（1+3+左贵妃）',1699.00,2499.00,'直降','已售',2576),
 (NULL,'./img/index/f8/floor5.jpg','名流之选 巴西进口头层黄牛皮 五档调节头枕左转角沙发（1+3+左贵妃）',1699.00,2499.00,'直降','已售',2576);
 /*网页脚*/
 CREATE TABLE mll_foot_title(
  jid1 INT PRIMARY KEY AUTO_INCREMENT,
  title VARCHAR(64)
);
INSERT INTO mll_foot_title VALUES
 (NULL,"客服热线（9:00-22:00）"),
 (NULL,"4000098666"),
 (NULL,"美乐乐在全国体验店175家、样板间1家"),
 (NULL,"查看全国体验店"), 
 (NULL,"免费发送到手机"), 

 (NULL,"关于美乐乐"), 
 (NULL,"公司简介"),  
 (NULL,"媒体聚焦"),  
 (NULL,"体验馆"),
 (NULL,"诚聘英才"),
 (NULL,"招商加盟"),    
 (NULL,"联系我们"), 

 (NULL,"新手指南"),
 (NULL,"注册新用户"),
 (NULL,"会员级别"),
 (NULL,"金币说明"), 
 (NULL,"乐币说明"),
 (NULL,"订购家具流程"),
 (NULL,"体验馆购买指导"),

 (NULL,"配送安装"),
 (NULL,"收货指南"),
 (NULL,"体验馆服务费"),
 (NULL,"物流配送"),
 (NULL,"家具体积估算表"),

 (NULL,"售后服务"),
 (NULL,"如何申请退款"),
 (NULL,"维修补件说明"),
 (NULL,"贵就赔"),
 (NULL,"30天无忧退换货"),
 (NULL,"建材保修政策"),
 (NULL,"家具保修"),

 (NULL,"购物保障"),
 (NULL,"正品保证"),
 (NULL,"注册协议"),
 (NULL,"隐私保护"),
 (NULL,"免责声明"),
  (NULL,"免责声明"),

 (NULL,"官方微信"), 
 (NULL, '装修网|'),
 (NULL,'装修效果图'),
 (NULL,'家具图片|'),
 (NULL,'家居资讯|'),
 (NULL,'生活百科|'),
 (NULL,'家私导购|'),
 (NULL,'品牌展厅|'),
 (NULL,'装修论坛|'),
 (NULL,'客服中心|'),
 (NULL,'网站地图|'),
 (NULL,'友情链接|'),
 (NULL,'更多'),  

 (NULL,'copy'),
 (NULL,'2005-2018'),
 (NULL,'美乐乐'),
 (NULL,'天津美维信息技术有限公司'),
 (NULL,'版权所有'),
 (NULL,'并保留所有权利'),
 (NULL,'ICP备案证书号'),
 (NULL,'粤ICP备08008334号'),

 (NULL,'诚信网站'),
 (NULL,'认证联盟品牌官网'),
 (NULL,'可信网站信用评价'),
 (NULL,'经营网站备案信息');
 /**/
 CREATE TABLE mll_foot_img(
 jid2 INT PRIMARY KEY AUTO_INCREMENT,
  img VARCHAR(128),
  title VARCHAR(64)
);
INSERT INTO mll_foot_img VALUES
(NULL,'./img/foot/o2o.png','美乐乐O2O'),
(NULL,'./img/foot/test.png','全国体验馆'),
(NULL,'./img/foot/cup.png','双重质检'),
(NULL,'./img/foot/sale.png','售后无忧'),
(NULL,'./img/foot/creat.png','原创设计'),
(NULL,'./img/foot/global.png','全球采购'),
(NULL,'./img/foot/name.png','万千口碑'),
(NULL,'./img/foot/peploles.png','团队优势');
/*健康时讯*/
CREATE TABLE mll_news(
   id INT PRIMARY KEY AUTO_INCREMENT,
   title VARCHAR(255),
   img_url VARCHAR(255),
   ctime DATETIME,
   point INT,
   content VARCHAR(2000)
);
INSERT INTO mll_news VALUES
(NULL,'123','./img/index/f2/floor6.jpg',now(),0,'123'),
(NULL,'123','./img/index/f2/floor6.jpg',now(),0,'124'),
(NULL,'123','./img/index/f2/floor6.jpg',now(),0,'125'),
(NULL,'123','./img/index/f2/floor6.jpg',now(),0,'126'),
(NULL,'123','./img/index/f2/floor6.jpg',now(),0,'127'),
(NULL,'123','./img/index/f2/floor6.jpg',now(),0,'128'),
(NULL,'123','./img/index/f2/floor6.jpg',now(),0,'129'),
(NULL,'123','./img/index/f2/floor6.jpg',now(),0,'12a'),
(NULL,'123','./img/index/f2/floor6.jpg',now(),0,'12b'),
(NULL,'123','./img/index/f2/floor6.jpg',now(),0,'12c'),
(NULL,'123','./img/index/f2/floor6.jpg',now(),0,'12d'),
(NULL,'123','./img/index/f2/floor6.jpg',now(),0,'12e'),
(NULL,'123','./img/index/f2/floor6.jpg',now(),0,'12f'),
(NULL,'123','./img/index/f2/floor6.jpg',now(),0,'12g'),
(NULL,'123','./img/index/f2/floor6.jpg',now(),0,'12h'),
(NULL,'123','./img/index/f2/floor6.jpg',now(),0,'12i'),
(NULL,'123','./img/index/f2/floor6.jpg',now(),0,'12j'),
(NULL,'123','./img/index/f2/floor6.jpg',now(),0,'12k'),
(NULL,'123','./img/index/f2/floor6.jpg',now(),0,'12l'),
(NULL,'123','./img/index/f2/floor6.jpg',now(),0,'12m'),
(NULL,'123','./img/index/f2/floor6.jpg',now(),0,'12n'),
(NULL,'123','./img/index/f2/floor6.jpg',now(),0,'12o');
/*创建评论列表*/
CREATE TABLE mll_comment(
    id INT PRIMARY KEY AUTO_INCREMENT,
    content VARCHAR(50),
    ctime DATETIME,
    nid INT
);
INSERT INTO mll_comment VALUES
 (null,'赞一个1',now(),5),
 (null,'赞一个2',now(),5),
 (null,'赞一个3',now(),5),
 (null,'赞一个4',now(),5),
 (null,'赞一个5',now(),5),
 (null,'赞一个6',now(),5),
 (null,'赞一个7',now(),5),
 (null,'赞一个8',now(),5),
 (null,'赞一个9',now(),5),
 (null,'赞一个10',now(),5),
 (null,'赞一个11',now(),5);
 /*创建用户登录列表*/
CREATE TABLE mll_login(
    id INT PRIMARY KEY AUTO_INCREMENT,
    uname VARCHAR(25),
    upwd VARCHAR(32)
);
INSERT INTO mll_login VALUES(NULL,'tom',md5('123')),
(NULL,'jerry',md5('123')),
(NULL,'mingming',md5('123')),
(NULL,'dingding',md5('123')),
(NULL,'dangdang',md5('123'));
/*购物车列表*/
CREATE TABLE mll_cart(
    id INT PRIMARY KEY AUTO_INCREMENT,
    count INT,
    price DECIMAL(15,2),
    pid INT,
    uid INT
);
/**用户信息**/
CREATE TABLE mll_user(
  id INT PRIMARY KEY AUTO_INCREMENT,
  uname VARCHAR(32),
  upwd VARCHAR(32),
  email VARCHAR(64),
  phone VARCHAR(16),

  avatar VARCHAR(128),        #头像图片路径
  user_name VARCHAR(32),      #用户名，如王小明
  gender INT                  #性别  0-女  1-男
);
/**用户信息**/
INSERT INTO mll_user VALUES
(NULL, 'dingding', '123456', 'ding@qq.com', '13501234567', 'img/avatar/default.png', '丁伟', '1'),
(NULL, 'dangdang', '123456', 'dang@qq.com', '13501234568', 'img/avatar/default.png', '林当', '1'),
(NULL, 'doudou', '123456', 'dou@qq.com', '13501234569', 'img/avatar/default.png', '窦志强', '1'),
(NULL, 'yaya', '123456', 'ya@qq.com', '13501234560', 'img/avatar/default.png', '秦小雅', '0');
//加载模块
const express=require('express');
const index=require('./routes/app_router');
const bodyParser=require('body-parser');
//创建服务器对象
var app=express();
//监听端口
app.listen(5050);
//
app.use(bodyParser.urlencoded({extended:false}))
//托管静态资源
app.use(express.static('public'));
app.use(express.static('dist'));
//加载跨域模块cors
const cors=require('cors');
//配置跨域访问模块
app.use(cors({origin:['http://127.0.0.1:8080','http://localhost:8080'],credentials:true}));
//引入模块
const session=require("express-session");
//配置
app.use(session({
  secret:"128位随机字符",//安全字符串
  resave:false,//每次请求是否更新数据
  saveUninitialized:true,//初始化时保存数据
  cookie:{
    maxAge:1000*60*60*8
  }
}));
//使用路由器来管理路由
app.use("/index",index);

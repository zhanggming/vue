const express=require("express")
const pool=require("../pool")
const router=express.Router();

//获取轮播图图片
router.get("/imglist",(req,res)=>{
   var ids=req.query.ids;
    var sql=`select * from  mll_index_carousel where cid in(1,2,3,4)`;
    //var id=req.query.id;
    //var sql=`select * from bsk_imges where id=?`
    pool.query(sql,(err,result)=>{
      if(err) console.log(err);
      var list=result;
      res.send(list)
    })
})
//功能二:获取健康时讯列表分页显示
router.get("/newslist",(req,res)=>{
  //1.获取参数
  var pno=req.query.pno;
  var pageSize=req.query.pageSize;
  //2.设置默认值pno 1 pageSize7
  if(!pno){
      pno=1;
  }
  if(!pageSize){
      pageSize=7;
  }
  //创建sql语句
  var sql="SELECT id,title,img_url";
  sql+=" ,ctime,point";
  sql+=" FROM mll_news";
  sql+=" LIMIT ?,?";
  var ps=parseInt(pageSize);
  var offset=(pno-1)*pageSize;
  pool.query(sql,[offset,ps],(err,result)=>{
      if(err)throw err;
      res.send({code:1,data:result});
  })
});
//功能三：获取一条新闻详细信息
router.get("/findNewsInfo",(req,res)=>{
    //获取参数
    var id=req.query.id;
    //创建正则表达式
    var reg=/^\d{1,}$/;
    //如果验证失败 输出错误信息
    if(!reg.test(id)){
        res.send({code:-1,msg:"新闻格式有误"});
        return;
    }
    //创建sql
    var sql=" SELECT id,title,content,ctime";
    sql+=" ,img_url FROM mll_news";
    sql+=" WHERE id=?"
    //发送sql语句
    pool.query(sql,[id],(err,result)=>{
        if(err)throw err;
        res.send({code:1,data:result});
    })
})
//功能四获取评论列表
router.get("/getComment",(req,res)=>{
    var nid=req.query.nid;
    var pno=req.query.pno;
    var pageSize=req.query.pageSize;
    if(!pno){pno=1}
    if(!pageSize){pageSize=5}
    var sql=" SELECT id,content,ctime,nid";
    sql+=" FROM mll_comment";
    sql+=" WHERE nid=?";
    sql+=" LIMIT ?,?";
    var offset=(pno-1)*pageSize;
    pageSize=parseInt(pageSize);
    pool.query(sql,[nid,offset,pageSize],(err,result)=>{
        if(err)throw err;
        res.send({code:1,data:result})
    })
})
//功能五发表评论
router.post("/addComment",(req,res)=>{
    var nid=req.body.nid;
    var content=req.body.content;
    var sql="INSERT INTO mll_comment VALUES";
    sql+="(NULL,?,now(),?)";
    pool.query(sql,[content,nid],(err,result)=>{
        if(err)throw err;
        if(result.affectedRows>0){
            res.send({code:1,msg:"评论发表成功"})
        }else{
            res.send({code:-1,msg:"评论发表失败"})
        }
    })
})
//功能六商品分页显示
router.get("/products",(req,res)=>{
    //参数
    var pno=req.query.pno;
    var pageSize=req.query.pageSize;
    //允许使用默认值
    if(!pno){pno=1}
    if(!pageSize){pageSize=7}
    //sql
    var sql=" SELECT fid,img,title,price1";
    sql+=" ,discount,subtitle";
    sql+=" FROM mll_index_firstFloor";
    sql+=" LIMIT ?,?";
    //json
    var offset=(pno-1)*pageSize;
    pageSize=parseInt(pageSize);
    pool.query(sql,[offset,pageSize],(err,result)=>{
        if(err)throw err;
        res.send({code:1,data:result})
    })
})
//功能七登录
router.get("/login",(req,res)=>{
    var uname=req.query.uname;
    var upwd=req.query.upwd;
    var sql="SELECT id FROM mll_login WHERE uname=? AND upwd=md5(?)";
    pool.query(sql,[uname,upwd],(err,result)=>{
        if(err)throw err;
        if(result.length==0){
            res.send({code:-1,msg:"用户名或密码有误"});
        }else{
            var id=result[0].id;//获取当前用户ID
            req.session.uid=id;//保存到sesion
            //console.log(req.session.uid);
            res.send({code:1,msg:"登录成功"})
        }
    })
})
//功能八添加购物车
router.get("/addcart",(req,res)=>{
     //判断用户是否登录
  if(!req.session.uid){
    res.send({code:-1,msg:'请登录'})
    return;
  }
    //参数
    var pid=parseInt(req.query.pid);
    var count=1;
    var uid=req.session.uid;
    //var uid=parseInt(req.query.uid);
    var price=parseInt(req.query.price);
    var sql="SELECT id FROM mll_cart";
    sql+=" WHERE uid=? AND pid=?";
    pool.query(sql,[uid,pid],(err,result)=>{
        if(err)throw err;
        if(result.length==0){
          var sql=`INSERT INTO mll_cart`;
          sql+=` VALUES(null,1,${price},${pid},${uid})`
        }else{
            var sql=`UPDATE mll_cart`
            sql+=` SET count=count+1 WHERE pid=${pid} AND uid=${uid}`;
        }
        pool.query(sql,(err,result)=>{
            if(err)throw err;
            if(result.affectedRows>0){
                res.send({code:1,msg:"添加成功"})
            }else{
                res.send({code:-1,msg:"添加失败"})
            }
        })
    })
})
//功能九
//功能九获取购物车列表
router.get("/cartlist",(req,res)=>{
    if(!req.session.uid){
        res.send({code:-1,msg:'请登录'})
        return;
      }
    var uid = req.session.uid;
   var sql=" SELECT c.id,c.count,c.price,";
   sql+=" c.uid,c.pid,p.title,p.img" 
   sql+=" FROM mll_cart c,mll_index_firstFloor p";
   sql+=" WHERE p.fid=c.id";
   sql+=" AND c.uid=?";
   pool.query(sql,[uid],(err,result)=>{
       if(err)throw err;
       res.send({code:1,data:result}) 
   })
})
//功能10删除购物车中的一个商品
router.get("/delCartItem",(req,res)=>{
    //参数
    var id=req.query.id;
    //sql
    var sql="DELETE FROM mll_cart WHERE id=?";
    //json
    pool.query(sql,[id],(err,result)=>{
        if(err)throw err;
        if(result.affectedRows>0){
            res.send({code:1,msg:"删除成功"})
        }else{
            res.send({code:-1,msg:"删除失败"})
        }
    })
})
//功能11购物车删除多个商品
router.get("/removeMItem",(req,res)=>{
    //参数
    var ids=req.query.ids;
    //sql
    var sql="DELETE FROM mll_cart";
    sql+=" WHERE id IN ("+ids+")";
    //json
    pool.query(sql,(err,result)=>{
        if(err)throw err;
        if(result.affectedRows>0){
            res.send({code:1,msg:"删除成功"})
        }else{
            res.send({code:-1,msg:"删除失败"})
        }
    })
})
//功能12退出登录
router.get("/logout",(req,res)=>{
    //清空uid
    req.session.uid=null;
    //返回消息
    res.send({code:1,msg:"已退出"});
})
//功能13商品搜索
router.get("/search",(req,res)=>{
    //获取参数
    var key=req.query.key;
    var pno=req.query.pno;
    var pageSize=req.query.pageSize;
    if(!pno){
      pno=1;
    }
    if(!pageSize){
      pageSize=7;
    }
   //sql
    var sql=` SELECT fid,title,price1`;
   sql+=` ,img,subtitle`;
   sql+=` FROM mll_index_firstFloor WHERE title LIKE ?`;
   sql+=` LIMIT ?,?`;
   //转整形
   var pageSize=parseInt(pageSize);
   var offset=(pno-1)*pageSize;
   pool.query(sql,["%"+key+"%",offset,pageSize],(err,result)=>{
     if(err)throw err;
     res.send({code:1,data:result})
   });
});
//
//导出路由
module.exports=router;
